
###To make more worlds for your bungeecord server, simply copy the Server-1 folder###
##or create a new folder and copy the run.bat file from Server-1 to the new folder.##
